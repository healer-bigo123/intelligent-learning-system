"""
数据库初始化脚本 - 填充示例数据
运行方式: cd backend && python init_data.py
"""
import sys
import os

# 添加项目根目录到路径
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

from datetime import datetime, timedelta
from sqlalchemy.orm import Session

from app.models.database import (
    get_db, User, UserRole, StudyMaterial, Mistake, Exercise,
    Achievement, LearningPath, Classroom, ClassroomMember,
    init_db
)
from app.core.security import get_password_hash


def create_test_users(db: Session):
    """创建测试用户"""
    print("[INIT] 创建测试用户...")

    users_data = [
        {
            "id": "user-001",
            "username": "student1",
            "password": "123456",
            "email": "student1@example.com",
            "nickname": "张同学",
            "role": "student",
        },
        {
            "id": "user-002",
            "username": "teacher1",
            "password": "123456",
            "email": "teacher1@example.com",
            "nickname": "李老师",
            "role": "teacher",
        },
    ]

    for u in users_data:
        existing = db.query(User).filter(User.username == u["username"]).first()
        if existing:
            print(f"  [SKIP] 用户已存在: {u['username']}")
            continue

        user = User(
            id=u["id"],
            username=u["username"],
            email=u["email"],
            hashed_password=get_password_hash(u["password"]),
            nickname=u["nickname"],
            role=u["role"],
            status="active",
            created_at=datetime.utcnow(),
        )
        db.add(user)

        # 创建角色记录
        role = UserRole(
            user_id=u["id"],
            role=u["role"],
            permissions='["read", "write", "chat"]',
        )
        db.add(role)
        print(f"  [OK] 创建用户: {u['nickname']} ({u['username']})")

    db.commit()


def create_study_materials(db: Session):
    """创建学习资料"""
    print("[INIT] 创建学习资料...")

    materials = [
        {
            "user_id": "user-001",
            "title": "三角函数诱导公式大全",
            "content": "诱导公式是三角函数中的重要公式，用于将任意角的三角函数转化为锐角三角函数。\n\n基本诱导公式：\n1. sin(-a) = -sin(a)\n2. cos(-a) = cos(a)\n3. sin(π-a) = sin(a)\n4. cos(π-a) = -cos(a)\n5. sin(π/2-a) = cos(a)\n6. cos(π/2-a) = sin(a)\n\n记忆口诀：奇变偶不变，符号看象限。",
            "subject": "数学",
            "grade": "高一",
            "material_type": "公式",
            "knowledge_point": "三角函数",
            "tags": "高考,重点,公式",
            "source": "人教版教材",
            "difficulty": 3,
        },
        {
            "user_id": "user-001",
            "title": "一元二次方程求根公式推导",
            "content": "一元二次方程 ax² + bx + c = 0 (a≠0) 的求根公式：\n\nx = (-b ± √(b²-4ac)) / 2a\n\n推导过程：\n1. 方程两边除以 a：x² + (b/a)x + c/a = 0\n2. 配方：x² + (b/a)x = -(c/a)\n3. x² + (b/a)x + (b/2a)² = (b/2a)² - c/a\n4. (x + b/2a)² = (b²-4ac)/4a²\n5. 开方得求根公式\n\n判别式 Δ = b²-4ac\n- Δ > 0：两个不等实根\n- Δ = 0：两个相等实根\n- Δ < 0：无实根",
            "subject": "数学",
            "grade": "初三",
            "material_type": "知识点",
            "knowledge_point": "一元二次方程",
            "tags": "中考,重点,推导",
            "source": "课堂笔记",
            "difficulty": 2,
        },
        {
            "user_id": "user-001",
            "title": "英语时态总结：一般现在时 vs 现在进行时",
            "content": "一般现在时：\n- 表示经常性、习惯性的动作\n- 结构：主语 + 动词原形/第三人称单数\n- 例句：I play basketball every day.\n\n现在进行时：\n- 表示此时此刻正在进行的动作\n- 结构：主语 + am/is/are + doing\n- 例句：I am playing basketball now.\n\n时间标志词：\n- 一般现在时：always, usually, often, every day\n- 现在进行时：now, at the moment, look, listen",
            "subject": "英语",
            "grade": "初一",
            "material_type": "知识点",
            "knowledge_point": "时态",
            "tags": "基础,语法,对比",
            "source": "网络整理",
            "difficulty": 1,
        },
        {
            "user_id": "user-001",
            "title": "牛顿三大定律",
            "content": "第一定律（惯性定律）：\n一切物体在没有受到外力作用时，总保持静止或匀速直线运动状态。\n\n第二定律（加速度定律）：\nF = ma，物体的加速度与所受合力成正比，与质量成反比。\n\n第三定律（作用力与反作用力）：\n两个物体之间的作用力和反作用力总是大小相等、方向相反、作用在同一条直线上。\n\n应用示例：\n- 第一定律：汽车急刹车时乘客向前倾\n- 第二定律：推箱子，力越大加速度越大\n- 第三定律：人走路时脚向后蹬地，地给人向前的力",
            "subject": "物理",
            "grade": "高一",
            "material_type": "知识点",
            "knowledge_point": "力学",
            "tags": "高考,重点,定律",
            "source": "人教版教材",
            "difficulty": 3,
        },
        {
            "user_id": "user-001",
            "title": "化学方程式配平方法",
            "content": "1. 最小公倍数法\n找出左右两边各出现一次且原子个数相差较大的元素，求最小公倍数。\n\n2. 奇数配偶法\n某元素在方程式两边一奇一偶时，将奇数配成偶数。\n\n3. 观察法\n从复杂的化学式入手，推断其他物质的系数。\n\n4. 归一法\n令最复杂物质的系数为1，再推导其他物质。\n\n例：配平 C₂H₆ + O₂ → CO₂ + H₂O\n解：令 C₂H₆ 系数为 1，则 CO₂ 为 2，H₂O 为 3，O₂ 为 7/2，同乘 2 得：\n2C₂H₆ + 7O₂ → 4CO₂ + 6H₂O",
            "subject": "化学",
            "grade": "初三",
            "material_type": "例题",
            "knowledge_point": "化学方程式",
            "tags": "中考,技巧,配平",
            "source": "整理",
            "difficulty": 3,
        },
        {
            "user_id": "user-001",
            "title": "细胞的基本结构",
            "content": "动物细胞结构：\n1. 细胞膜：控制物质进出\n2. 细胞质：细胞代谢的主要场所\n3. 细胞核：含有遗传物质，控制细胞生命活动\n\n植物细胞特有结构：\n1. 细胞壁：支持和保护作用\n2. 叶绿体：光合作用的场所\n3. 液泡：储存物质，维持细胞形态\n\n细胞器功能：\n- 线粒体：有氧呼吸的主要场所，动力车间\n- 核糖体：合成蛋白质\n- 内质网：蛋白质加工和运输\n- 高尔基体：蛋白质加工、分类、包装",
            "subject": "生物",
            "grade": "初一",
            "material_type": "知识点",
            "knowledge_point": "细胞",
            "tags": "基础,结构,对比",
            "source": "人教版教材",
            "difficulty": 2,
        },
        {
            "user_id": "user-001",
            "title": "中国朝代顺序歌",
            "content": "夏商与西周，东周分两段。\n春秋和战国，一统秦两汉。\n三分魏蜀吴，二晋前后延。\n南北朝并立，隋唐五代传。\n宋元明清后，皇朝至此完。\n\n重要朝代记忆点：\n- 夏朝：中国第一个奴隶制王朝\n- 秦朝：第一个统一的封建王朝，秦始皇\n- 唐朝：贞观之治、开元盛世\n- 宋朝：经济文化繁荣，但军事较弱\n- 明朝：郑和下西洋\n- 清朝：中国最后一个封建王朝",
            "subject": "历史",
            "grade": "初一",
            "material_type": "笔记",
            "knowledge_point": "朝代",
            "tags": "基础,记忆,口诀",
            "source": "网络",
            "difficulty": 1,
        },
        {
            "user_id": "user-001",
            "title": "Python 列表推导式",
            "content": "列表推导式是 Python 中简洁创建列表的方式。\n\n基本语法：\n[表达式 for 变量 in 可迭代对象 if 条件]\n\n示例：\n1. 创建平方数列表\n   squares = [x**2 for x in range(10)]\n   # [0, 1, 4, 9, 16, 25, 36, 49, 64, 81]\n\n2. 筛选偶数\n   evens = [x for x in range(20) if x % 2 == 0]\n\n3. 嵌套循环\n   pairs = [(x, y) for x in range(3) for y in range(3)]\n\n优点：代码简洁、执行效率高\n注意：过于复杂的推导式会降低可读性",
            "subject": "编程",
            "grade": "大学",
            "material_type": "知识点",
            "knowledge_point": "Python基础",
            "tags": "编程,Python,技巧",
            "source": "教程",
            "difficulty": 2,
        },
    ]

    for i, m in enumerate(materials):
        existing = db.query(StudyMaterial).filter(StudyMaterial.title == m["title"]).first()
        if existing:
            print(f"  [SKIP] 资料已存在: {m['title']}")
            continue

        material = StudyMaterial(
            id=f"material-{i+1:03d}",
            **m,
            views=0,
            status="active",
            created_at=datetime.utcnow(),
        )
        db.add(material)
        print(f"  [OK] 创建资料: {m['title']}")

    db.commit()


def create_mistakes(db: Session):
    """创建示例错题"""
    print("[INIT] 创建示例错题...")

    mistakes = [
        {
            "user_id": "user-001",
            "subject": "数学",
            "question": "若函数 f(x) = x² - 2x + 3，求 f(2) 的值。",
            "correct_answer": "3",
            "user_answer": "5",
            "analysis": "错误原因：代入时计算错误。f(2) = 2² - 2×2 + 3 = 4 - 4 + 3 = 3",
            "knowledge_point": "函数求值",
            "tags": "易错,计算",
            "source": "课堂练习",
            "difficulty": 2,
            "status": "unsolved",
        },
        {
            "user_id": "user-001",
            "subject": "数学",
            "question": "求解方程：2x + 5 = 13",
            "correct_answer": "x = 4",
            "user_answer": "x = 9",
            "analysis": "错误原因：移项时符号错误。正确步骤：2x = 13 - 5 = 8，x = 4",
            "knowledge_point": "一元一次方程",
            "tags": "基础,移项",
            "source": "作业",
            "difficulty": 1,
            "status": "reviewing",
        },
        {
            "user_id": "user-001",
            "subject": "英语",
            "question": "选择正确的时态：I ______ (play) basketball now.",
            "correct_answer": "am playing",
            "user_answer": "play",
            "analysis": "错误原因：now 是现在进行时的标志词，应该用 be + doing 结构。",
            "knowledge_point": "现在进行时",
            "tags": "时态,标志词",
            "source": "单元测试",
            "difficulty": 1,
            "status": "unsolved",
        },
        {
            "user_id": "user-001",
            "subject": "物理",
            "question": "一个物体质量为 2kg，受到 10N 的力，求加速度。",
            "correct_answer": "5 m/s²",
            "user_answer": "20 m/s²",
            "analysis": "错误原因：公式记错。F=ma，所以 a=F/m=10/2=5 m/s²",
            "knowledge_point": "牛顿第二定律",
            "tags": "公式,计算",
            "source": "期中考试",
            "difficulty": 2,
            "status": "mastered",
        },
    ]

    for i, m in enumerate(mistakes):
        existing = db.query(Mistake).filter(Mistake.question == m["question"]).first()
        if existing:
            print(f"  [SKIP] 错题已存在")
            continue

        mistake = Mistake(
            id=f"mistake-{i+1:03d}",
            **m,
            review_count=1,
            created_at=datetime.utcnow(),
        )
        db.add(mistake)
        print(f"  [OK] 创建错题: {m['subject']} - {m['knowledge_point']}")

    db.commit()


def create_exercises(db: Session):
    """创建示例练习题"""
    print("[INIT] 创建示例练习题...")

    exercises = [
        {
            "user_id": "user-001",
            "subject": "数学",
            "type": "choice",
            "question": "下列哪个数是质数？",
            "options": '["9", "15", "17", "21"]',
            "correct_answer": "2",
            "explanation": "17 只能被 1 和 17 整除，是质数。其他数都有其他因数。",
            "knowledge_point": "质数与合数",
            "difficulty": 2,
        },
        {
            "user_id": "user-001",
            "subject": "数学",
            "type": "choice",
            "question": "函数 y = 2x + 1 的图像经过哪个象限？",
            "options": '["第一、二象限", "第一、三象限", "第一、二、三象限", "全部象限"]',
            "correct_answer": "2",
            "explanation": "斜率 k=2>0，截距 b=1>0，图像经过第一、二、三象限。",
            "knowledge_point": "一次函数图像",
            "difficulty": 3,
        },
        {
            "user_id": "user-001",
            "subject": "英语",
            "type": "choice",
            "question": "She ______ to school every day.",
            "options": '["go", "goes", "going", "went"]',
            "correct_answer": "1",
            "explanation": "every day 表示习惯性动作，用一般现在时，主语是第三人称单数，动词加 -es。",
            "knowledge_point": "一般现在时",
            "difficulty": 1,
        },
        {
            "user_id": "user-001",
            "subject": "物理",
            "type": "fill_blank",
            "question": "光在真空中的传播速度约为 ______ m/s。",
            "options": None,
            "correct_answer": "3×10⁸",
            "explanation": "光在真空中的速度是宇宙中最快的速度，约为 3×10⁸ m/s。",
            "knowledge_point": "光学基础",
            "difficulty": 1,
        },
    ]

    for i, e in enumerate(exercises):
        existing = db.query(Exercise).filter(Exercise.question == e["question"]).first()
        if existing:
            print(f"  [SKIP] 练习题已存在")
            continue

        exercise = Exercise(
            id=f"exercise-{i+1:03d}",
            **e,
            source="manual",
            status="active",
            created_at=datetime.utcnow(),
        )
        db.add(exercise)
        print(f"  [OK] 创建练习: {e['subject']} - {e['knowledge_point']}")

    db.commit()


def create_achievements(db: Session):
    """创建成就定义"""
    print("[INIT] 创建成就定义...")

    achievements = [
        {
            "id": "ach-001",
            "name": "初次登场",
            "description": "完成首次登录",
            "icon": "🎯",
            "condition_type": "exercise_count",
            "condition_value": 1,
        },
        {
            "id": "ach-002",
            "name": "练习新手",
            "description": "完成10道练习题",
            "icon": "📚",
            "condition_type": "exercise_count",
            "condition_value": 10,
        },
        {
            "id": "ach-003",
            "name": "练习达人",
            "description": "完成50道练习题",
            "icon": "🏆",
            "condition_type": "exercise_count",
            "condition_value": 50,
        },
        {
            "id": "ach-004",
            "name": "学霸之路",
            "description": "完成100道练习题",
            "icon": "👑",
            "condition_type": "exercise_count",
            "condition_value": 100,
        },
        {
            "id": "ach-005",
            "name": "坚持就是胜利",
            "description": "连续学习7天",
            "icon": "🔥",
            "condition_type": "streak_days",
            "condition_value": 7,
        },
        {
            "id": "ach-006",
            "name": "学习狂人",
            "description": "连续学习30天",
            "icon": "⚡",
            "condition_type": "streak_days",
            "condition_value": 30,
        },
        {
            "id": "ach-007",
            "name": "收藏夹达人",
            "description": "收藏20条学习资料",
            "icon": "⭐",
            "condition_type": "material_count",
            "condition_value": 20,
        },
        {
            "id": "ach-008",
            "name": "百发百中",
            "description": "练习正确率达到90%",
            "icon": "🎯",
            "condition_type": "accuracy",
            "condition_value": 90,
        },
    ]

    for a in achievements:
        existing = db.query(Achievement).filter(Achievement.id == a["id"]).first()
        if existing:
            print(f"  [SKIP] 成就已存在: {a['name']}")
            continue

        ach = Achievement(**a, created_at=datetime.utcnow())
        db.add(ach)
        print(f"  [OK] 创建成就: {a['name']}")

    db.commit()


def create_learning_paths(db: Session):
    """创建示例学习路径"""
    print("[INIT] 创建示例学习路径...")

    import json

    paths = [
        {
            "user_id": "user-001",
            "title": "高一数学期末冲刺",
            "description": "系统复习高一数学重点知识，为期末考试做好准备",
            "steps": json.dumps([
                {"title": "函数基础", "description": "复习函数概念、定义域、值域", "duration": 120, "status": "completed"},
                {"title": "三角函数", "description": "掌握诱导公式、图像性质", "duration": 180, "status": "completed"},
                {"title": "数列", "description": "等差数列、等比数列求和", "duration": 150, "status": "active"},
                {"title": "立体几何", "description": "空间向量与线面关系", "duration": 200, "status": "pending"},
                {"title": "模拟测试", "description": "完成2套期末模拟卷", "duration": 180, "status": "pending"},
            ]),
            "status": "active",
        },
        {
            "user_id": "user-001",
            "title": "英语语法通关",
            "description": "从基础语法到高级语法，全面掌握英语语法体系",
            "steps": json.dumps([
                {"title": "时态入门", "description": "一般现在时、一般过去时", "duration": 90, "status": "completed"},
                {"title": "进行时态", "description": "现在进行时、过去进行时", "duration": 90, "status": "completed"},
                {"title": "完成时态", "description": "现在完成时、过去完成时", "duration": 120, "status": "active"},
                {"title": "被动语态", "description": "各种时态的被动形式", "duration": 100, "status": "pending"},
                {"title": "从句", "description": "定语从句、状语从句、名词性从句", "duration": 180, "status": "pending"},
            ]),
            "status": "active",
        },
    ]

    for i, p in enumerate(paths):
        existing = db.query(LearningPath).filter(LearningPath.title == p["title"]).first()
        if existing:
            print(f"  [SKIP] 路径已存在: {p['title']}")
            continue

        path = LearningPath(
            id=f"path-{i+1:03d}",
            **p,
            created_at=datetime.utcnow(),
        )
        db.add(path)
        print(f"  [OK] 创建路径: {p['title']}")

    db.commit()


def create_classrooms(db: Session):
    """创建示例课堂"""
    print("[INIT] 创建示例课堂...")

    classrooms = [
        {
            "id": "class-001",
            "code": "123456",
            "name": "高一数学精英班",
            "description": "针对数学基础较好的同学，深入讲解重点难点",
            "teacher_id": "user-002",
            "status": "active",
        },
    ]

    for c in classrooms:
        existing = db.query(Classroom).filter(Classroom.id == c["id"]).first()
        if existing:
            print(f"  [SKIP] 课堂已存在: {c['name']}")
            continue

        classroom = Classroom(
            **c,
            created_at=datetime.utcnow(),
        )
        db.add(classroom)

        # 添加老师为成员
        member = ClassroomMember(
            classroom_id=c["id"],
            user_id=c["teacher_id"],
            role="teacher",
        )
        db.add(member)

        # 添加学生为成员
        member2 = ClassroomMember(
            classroom_id=c["id"],
            user_id="user-001",
            role="student",
        )
        db.add(member2)

        print(f"  [OK] 创建课堂: {c['name']} (邀请码: {c['code']})")

    db.commit()


def main():
    print("=" * 50)
    print("SmartLearning 数据库初始化")
    print("=" * 50)

    # 确保表已创建
    init_db()

    # 获取数据库会话
    db = next(get_db())

    try:
        create_test_users(db)
        create_study_materials(db)
        create_mistakes(db)
        create_exercises(db)
        create_achievements(db)
        create_learning_paths(db)
        create_classrooms(db)

        print("\n" + "=" * 50)
        print("[OK] 数据初始化完成！")
        print("=" * 50)
        print("\n测试账号：")
        print("  学生: student1 / 123456")
        print("  老师: teacher1 / 123456")

    except Exception as e:
        print(f"\n[ERROR] 初始化失败: {e}")
        import traceback
        traceback.print_exc()
    finally:
        db.close()


if __name__ == "__main__":
    main()
